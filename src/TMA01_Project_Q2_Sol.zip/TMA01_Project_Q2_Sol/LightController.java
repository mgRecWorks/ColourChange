import ou.*;
import java.util.*;
/**
 * Class LightController
 * This class uses the Circle class, and the Shapes window 
 * to simulate a disco light, that grows and shrinks and 
 * changes colour. 
 * @author Monette Gordon M250 R0050097
 * @version 1.0
 */

public class LightController
{

   private Random randomNumberGenerator;
   private Circle light;
   /**
    * Default constructor for objects of class LightController.
    */
   public LightController()
   {
      super();
      this.randomNumberGenerator = new Random();
      this.light = new Circle(50, OUColour.GREEN);
      this.light.setXPos(122);
      this.light.setYPos(162);
      // Add your code for Q2 part (a)(i) here          
   }

   /**
    * Returns a randomly generated int between 0 (inclusive) 
    * and number (exclusive). For example if number is 6,
    * the method will return one of 0, 1, 2, 3, 4, or 5.
    */
   private int getRandomInt(int number)
   {
      return this.randomNumberGenerator.nextInt(number);
   }

   /**
    * Returns the instance variable, light.
    */
   public Circle getLight()
   {
      return this.light; 
   }

   /** 
    * Randomly sets the colour of the instance variable 
    * light to red, green, or purple.
    * When the message getRandomInt(anInt)is sent to an 
    * instance of LightController, the message answer is a 
    * randomly generated int between 0 (inclusive) 2 (exclusive)
    * will return one or 0, 1, 2 at random.
    */
   public void changeColour()
   {
      int randomInt = getRandomInt(3);
      if(randomInt == 0)
      {
         this.light.setColour(OUColour.RED);
      }
      if(randomInt == 1)
      {
         this.light.setColour(OUColour.GREEN);
      }
      if(randomInt == 2)
      {
         this.light.setColour(OUColour.PURPLE);
      }
      // Add your code for Q2 part (b) here
   }

   /** 
    * Grows the diameter of the circle referenced by the 
    * receiver's instance variable light, to the argument size.  
    * The diameter is incremented in steps of 2,
    * the xPos and yPos are decremented in steps of 1 until the
    * diameter reaches the value given by size. 
    * Between each step there is a random colour change.  The message 
    * delay(anInt) is used to slow down the graphical interface, as required.
    */   

   public void grow(int size)
   {   
      while (this.light.getDiameter() < size)
      {
         this.light.setDiameter(this.light.getDiameter() + 2);
         this.light.setXPos(this.light.getXPos() - 1);
         this.light.setYPos(this.light.getYPos() - 1);
         this.changeColour();
         this.delay(100);
      }
      // Add your code for Q2 part (c) here  
   }

   /** 
    * Shrinks the diameter of the circle referenced by the 
    * receiver's instance variable light, to the argument size.  
    * The diameter is decremented in steps of 2,
    * the xPos and yPos are incremented in steps of 1 until the
    * diameter reaches the value given by size. 
    * Between each step there is a random colour change.  The message 
    * delay(anInt) is used to slow down the graphical interface, as required.
    */     

   public void shrink(int size)
   { 

      while (this.light.getDiameter() >= size)
      {
         this.light.setDiameter(this.light.getDiameter() - 2);
         this.light.setXPos(this.light.getXPos() + 1);
         this.light.setYPos(this.light.getYPos() + 1);
         this.changeColour();
         this.delay(100);
      }
      // Add your code for Q2 part (d) here
   } 

   /** 
    * Expands the diameter of the light by the amount given by
    * sizeIncrease (changing colour as it grows).
    * 
    * The method then contracts the light until it reaches its
    * original size (changing colour as it shrinks).
    */     
   public void lightCycle(int sizeIncrease)
   {
      if(this.light.getDiameter()< (this.light.getDiameter() + sizeIncrease))
      {
         this.grow(this.light.getDiameter() + sizeIncrease);
      }
      if(this.light.getDiameter() >= (this.light.getDiameter() - sizeIncrease))
      {
         this.shrink(this.light.getDiameter() - sizeIncrease);
      }
      // Add your code for Q2 part (e) here
   }

   /** 
    * Prompts the user for number of growing and shrinking
    * cycles. Then prompts the user for the number of units
    * by which to increase the diameter of light.
    * Method then performs the requested growing and 
    * shrinking cycles.
    */     
   public void runLight()
   {  
      int input = Integer.parseInt(OUDialog.request("Enter number of cycles"));

      int sizeIncrease = Integer.parseInt(OUDialog.request("Enter an even integer to increase the diameter of the disco light"));

      for (int num = 0; num < input; num++) 

         if(num < input) 
         {
            this.lightCycle(sizeIncrease);
         }
      // Add your code for Q2 part (f) here
   }  

   /**
    * Causes execution to pause by time number of milliseconds.
    */
   private void delay(int time)
   {
      try
      {
         Thread.sleep(time); 
      }
      catch (Exception e)
      {
         System.out.println(e);
      } 
   }  
}